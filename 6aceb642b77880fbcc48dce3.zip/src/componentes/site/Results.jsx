import { useState } from "react";
import { useRevealStagger } from "@/hooks/useReveal";
import { SectionLabel } from "./SectionLabel";
import { BeforeAfterSlider } from "./BeforeAfterSlider";
import { SurgicalGallery } from "./SurgicalGallery";
import { Lightbox } from "./Lightbox";
import { beforeAfter } from "@/lib/siteData";

const DISCLAIMER =
  "Em cumprimento à Resolução CFM nº 2.336/2023, as imagens possuem caráter educativo. Os resultados variam de acordo com cada paciente. Em cumprimento à Lei Geral de Proteção de Dados Pessoais — LGPD, Lei nº 13.709/2018, os pacientes apresentados autorizaram o uso de suas imagens.";

const EDU = {
  blefaroplastia: [
    { k: "Condição / queixa", v: "Excesso de pele e bolsas palpebrais; comprometimento do campo visual." },
    { k: "Possibilidades de indicação", v: "Blefaroplastia superior, inferior ou associada." },
    { k: "Fatores que influenciam", v: "Avaliação clínica, estrutura palpebral e expectativas." },
    { k: "Limitações / complicações", v: "Cicatrização, edema e assimetrias transitórias; acompanhamento médico." },
  ],
  estetica: [
    { k: "Condição / queixa", v: "Manchas, textura, flacidez e sinais de envelhecimento." },
    { k: "Possibilidades de indicação", v: "Laser, ultrassom e protocolos personalizados." },
    { k: "Fatores que influenciam", v: "Tipo de pele, histórico e resposta individual." },
    { k: "Limitações / complicações", v: "Resultados graduais; possibilidade de hiperpigmentação transitória." },
  ],
  cirurgia: [
    { k: "Condição / queixa", v: "Lesões, sinais e tumores cutâneos." },
    { k: "Possibilidades de indicação", v: "Exérese e reparo cirúrgico planejado." },
    { k: "Fatores que influenciam", v: "Localização, tamanho e tipo de lesão." },
    { k: "Limitações / complicações", v: "Cicatriz, sangramento e infecção — controlados com técnica e cuidado." },
  ],
};

function Education({ data }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-px bg-[hsl(30_12%_80%_/_0.6)]">
      {data.map((row) => (
        <div key={row.k} className="bg-background p-6">
          <p className="text-[11px] uppercase tracking-label text-muted-foreground mb-2">{row.k}</p>
          <p className="text-[14px] leading-relaxed">{row.v}</p>
        </div>
      ))}
    </div>
  );
}

export function Results() {
  const ref = useRevealStagger();
  const [lightbox, setLightbox] = useState(null);

  return (
    <section id="resultados">
      <div ref={ref} className="mx-auto max-w-[1360px] px-6 md:px-12 py-12 md:py-20">
        <div className="reveal">
          <SectionLabel index="08">Casos clínicos</SectionLabel>
        </div>
        <h2 className="reveal mt-6 max-w-3xl font-heading font-light text-[30px] md:text-[40px] leading-[1.15] tracking-tight text-balance">
          Registros clínicos e cuidado individualizado.
        </h2>
        <p className="reveal mt-6 max-w-2xl text-[15px] md:text-[16px] leading-relaxed text-muted-foreground">
          Os registros a seguir têm caráter educativo e demonstram possibilidades de tratamento.
          Cada caso é único e a indicação é sempre individualizada.
        </p>

        {/* Blefaroplastia */}
        <div className="reveal mt-14">
          <h3 className="font-heading font-light text-[24px] md:text-[28px]">Blefaroplastia</h3>
          <div className="mt-6">
            <Education data={EDU.blefaroplastia} />
          </div>
          <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
            <BeforeAfterSlider
              before={beforeAfter.blef1.before}
              after={beforeAfter.blef1.after}
              aspect={beforeAfter.blef1.aspect}
              label={beforeAfter.blef1.label}
              onExpand={() => setLightbox("blef1")}
            />
            <BeforeAfterSlider
              before={beforeAfter.blef2.before}
              after={beforeAfter.blef2.after}
              aspect={beforeAfter.blef2.aspect}
              label={beforeAfter.blef2.label}
              onExpand={() => setLightbox("blef2")}
            />
          </div>
        </div>

        {/* Estéticos */}
        <div className="reveal mt-14">
          <h3 className="font-heading font-light text-[24px] md:text-[28px]">Procedimentos estéticos</h3>
          <div className="mt-6">
            <Education data={EDU.estetica} />
          </div>
          <div className="mt-8 flex justify-center">
            <div className="w-full max-w-[680px]">
              <BeforeAfterSlider
                before={beforeAfter.perioral.before}
                after={beforeAfter.perioral.after}
                aspect={beforeAfter.perioral.aspect}
                label={beforeAfter.perioral.label}
                onExpand={() => setLightbox("perioral")}
              />
            </div>
          </div>
        </div>

        {/* Cirurgia */}
        <div className="reveal mt-14">
          <h3 className="font-heading font-light text-[24px] md:text-[28px]">Cirurgia dermatológica</h3>
          <p className="mt-4 max-w-2xl text-[15px] leading-relaxed text-muted-foreground">
            Procedimentos cirúrgicos realizados com planejamento, técnica e acompanhamento.
          </p>
          <div className="mt-6">
            <Education data={EDU.cirurgia} />
          </div>
          <div className="mt-10">
            <SurgicalGallery />
          </div>
        </div>

        <p className="reveal mt-12 border-t hairline pt-6 text-[12px] leading-relaxed text-muted-foreground max-w-3xl">
          {DISCLAIMER}
        </p>
      </div>

      <Lightbox
        open={!!lightbox}
        onClose={() => setLightbox(null)}
        footer={DISCLAIMER}
      >
        {lightbox && (
          <BeforeAfterSlider
            before={beforeAfter[lightbox].before}
            after={beforeAfter[lightbox].after}
            aspect={beforeAfter[lightbox].aspect}
            label={beforeAfter[lightbox].label}
          />
        )}
      </Lightbox>
    </section>
  );
}

export default Results;