import { useReveal } from "@/hooks/useReveal";
import { SectionLabel } from "./SectionLabel";
import { images } from "@/lib/siteData";

export function Philosophy() {
  const ref = useReveal();
  return (
    <section className="relative overflow-hidden">
      <img
        src={images.texture}
        alt=""
        loading="lazy"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-background/88" />
      <div ref={ref} className="relative mx-auto max-w-3xl px-6 md:px-12 py-16 md:py-24 text-center reveal">
        <div className="flex justify-center">
          <SectionLabel>Filosofia</SectionLabel>
        </div>
        <h2 className="mt-6 font-heading font-light text-[30px] md:text-[40px] leading-[1.15] tracking-tight text-balance">
          Cuidar também é saber quando indicar.
        </h2>
        <p className="mt-6 text-[15px] md:text-[16px] leading-relaxed text-muted-foreground">
          Cada pele, cada história e cada objetivo pedem uma avaliação individualizada. Não há
          fórmula pronta — há escuta, exame clínico e indicação responsável.
        </p>
        <p className="mt-8 font-heading italic font-light text-[24px] md:text-[28px] text-foreground">
          Naturalidade. Precisão. Segurança.
        </p>
      </div>
    </section>
  );
}

export default Philosophy;