import { useEffect, useRef, useState } from "react";
import { Star, ChevronLeft, ChevronRight } from "lucide-react";
import { useRevealStagger } from "@/hooks/useReveal";
import { SectionLabel } from "./SectionLabel";
import { site } from "@/lib/siteData";

const ITEMS = [
  "Eu recomendo demais essa clínica, a Dra Juliana e sua equipe foram excelentes.",
  "Ótimo atendimento, tanto pela secretária quanto pela médica.",
  "Dra Juliana, sempre se atualizando com o que há de melhor no mercado.",
];

export function Testimonials() {
  const ref = useRevealStagger();
  const [idx, setIdx] = useState(0);
  const [paused, setPaused] = useState(false);
  const resumeRef = useRef(null);

  useEffect(() => {
    if (paused) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const t = setInterval(() => setIdx((i) => (i + 1) % ITEMS.length), 6000);
    return () => clearInterval(t);
  }, [paused]);

  const pause = () => {
    setPaused(true);
    if (resumeRef.current) clearTimeout(resumeRef.current);
    resumeRef.current = setTimeout(() => setPaused(false), 12000);
  };

  const prev = () => {
    setIdx((i) => (i - 1 + ITEMS.length) % ITEMS.length);
    pause();
  };
  const next = () => {
    setIdx((i) => (i + 1) % ITEMS.length);
    pause();
  };

  return (
    <section className="bg-secondary/40">
      <div ref={ref} className="mx-auto max-w-[1360px] px-6 md:px-12 py-12 md:py-20">
        <div className="reveal flex flex-col items-center text-center">
          <SectionLabel index="09">Depoimentos</SectionLabel>
          <h2 className="mt-6 max-w-3xl font-heading font-light text-[30px] md:text-[40px] leading-[1.15] tracking-tight text-balance">
            A experiência de quem já passou pela clínica.
          </h2>

          <div className="mt-10 flex items-center gap-1" aria-hidden="true">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className="h-5 w-5 fill-[hsl(30_12%_55%)] text-[hsl(30_12%_55%)]" />
            ))}
          </div>

          <blockquote
            onMouseEnter={() => setPaused(true)}
            onMouseLeave={() => setPaused(false)}
            className="mt-6 max-w-2xl font-heading font-light text-[24px] md:text-[30px] leading-snug min-h-[150px] md:min-h-[170px] text-balance"
          >
            “{ITEMS[idx]}”
          </blockquote>

          <div className="mt-2 flex items-center gap-4">
            <button onClick={prev} aria-label="Depoimento anterior" className="p-2 text-muted-foreground hover:text-foreground transition-colors">
              <ChevronLeft className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2">
              {ITEMS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setIdx(i);
                    pause();
                  }}
                  aria-label={`Depoimento ${i + 1}`}
                  className={`h-0.5 transition-all luxury-ease ${
                    i === idx ? "w-8 bg-foreground" : "w-4 bg-muted-foreground/40"
                  }`}
                />
              ))}
            </div>
            <button onClick={next} aria-label="Próximo depoimento" className="p-2 text-muted-foreground hover:text-foreground transition-colors">
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>

          <a
            href={site.googleReviews}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-10 inline-flex items-center border border-foreground px-6 py-3.5 text-[13px] uppercase tracking-[0.08em] luxury-ease hover:bg-secondary transition-colors"
          >
            Ver todas as avaliações no Google
          </a>
        </div>
      </div>
    </section>
  );
}

export default Testimonials;