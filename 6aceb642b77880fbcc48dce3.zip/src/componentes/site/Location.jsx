import { MapPin, Phone, MessageCircle } from "lucide-react";
import { useRevealStagger } from "@/hooks/useReveal";
import { SectionLabel } from "./SectionLabel";
import { site, whatsappLink } from "@/lib/siteData";

export function Location() {
  const ref = useRevealStagger();
  return (
    <section id="contato">
      <div ref={ref} className="mx-auto max-w-[1360px] px-6 md:px-12 py-12 md:py-20">
        <div className="reveal">
          <SectionLabel index="12">Localização</SectionLabel>
        </div>
        <h2 className="reveal mt-6 max-w-3xl font-heading font-light text-[30px] md:text-[40px] leading-[1.15] tracking-tight text-balance">
          Onde estamos.
        </h2>

        <div className="mt-12 grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-start">
          <div className="reveal space-y-6">
            <div>
              <p className="font-heading font-light text-[22px]">{site.clinic}</p>
              <p className="mt-3 flex items-start gap-3 text-[15px] text-muted-foreground">
                <MapPin className="h-5 w-5 shrink-0 mt-0.5 text-[hsl(30_12%_55%)]" />
                <span>
                  {site.address.line}
                  <br />
                  {site.address.city}
                  <br />
                  {site.address.cep}
                </span>
              </p>
            </div>

            <div className="space-y-3 border-t hairline pt-6">
              <a href={`tel:+${site.phoneIntl}`} className="flex items-center gap-3 text-[15px] hover:text-foreground text-muted-foreground transition-colors">
                <Phone className="h-5 w-5 text-[hsl(30_12%_55%)]" />
                {site.phone}
              </a>
              <a
                href={whatsappLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-[15px] hover:text-foreground text-muted-foreground transition-colors"
              >
                <MessageCircle className="h-5 w-5 text-[hsl(30_12%_55%)]" />
                {site.whatsapp}
              </a>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <a
                href={site.mapsDirections}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center bg-primary text-primary-foreground px-6 py-3.5 text-[13px] uppercase tracking-[0.08em] luxury-ease hover:opacity-90 transition-opacity"
              >
                Como chegar
              </a>
              <a
                href={whatsappLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center border border-foreground px-6 py-3.5 text-[13px] uppercase tracking-[0.08em] luxury-ease hover:bg-secondary transition-colors"
              >
                Falar pelo WhatsApp
              </a>
            </div>
          </div>

          <div className="reveal">
            <div className="w-full overflow-hidden border hairline">
              <iframe
                title="Mapa Clínica Reabilitar"
                src={site.mapsEmbed}
                className="w-full grayscale-[0.3] contrast-[0.95]"
                style={{ aspectRatio: "4 / 3", minHeight: "420px", border: 0 }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Location;