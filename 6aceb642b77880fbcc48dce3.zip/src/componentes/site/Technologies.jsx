import { useRevealStagger } from "@/hooks/useReveal";
import { SectionLabel } from "./SectionLabel";
import { images, whatsappLink } from "@/lib/siteData";

export function Technologies() {
  const ref = useRevealStagger();
  return (
    <section id="tecnologias">
      <div ref={ref} className="mx-auto max-w-[1360px] px-6 md:px-12 py-12 md:py-20">
        <div className="reveal">
          <SectionLabel index="05">Tecnologias</SectionLabel>
        </div>
        <h2 className="reveal mt-6 max-w-3xl font-heading font-light text-[30px] md:text-[40px] leading-[1.15] tracking-tight text-balance">
          Tecnologia aplicada com indicação médica.
        </h2>
        <p className="reveal mt-6 max-w-2xl text-[15px] md:text-[16px] leading-relaxed text-muted-foreground">
          Protocolos individualizados, escolhidos a partir de avaliação clínica. A tecnologia é
          um instrumento — a indicação é sempre médica e personalizada.
        </p>

        <div className="mt-12 space-y-6">
          {/* 1 — Laser CO2 Rennova */}
          <div className="reveal grid grid-cols-1 lg:grid-cols-12 gap-8 border hairline p-8 md:p-10">
            <div className="lg:col-span-5 flex justify-center items-center bg-secondary/40 p-6">
              <img
                src={images.laserCo2}
                alt="Laser de CO₂ Rennova Intense"
                loading="lazy"
                className="w-full max-w-[400px] aspect-[3/4] object-contain"
              />
            </div>
            <div className="lg:col-span-7">
              <h3 className="font-heading font-light text-[24px] md:text-[28px]">
                Laser de CO₂ — Rennova Intense
              </h3>
              <p className="mt-4 text-[15px] leading-relaxed text-muted-foreground">
                Qualidade, textura e firmeza da pele. Atua em manchas, rugas e cicatrizes,
                promovendo rejuvenescimento facial e melhora da flacidez palpebral.
              </p>
            </div>
          </div>

          {/* 2 — Laser CO2 íntimo */}
          <div className="reveal border hairline p-8 md:p-10">
            <h3 className="font-heading font-light text-[24px] md:text-[28px]">
              Laser de CO₂ e cuidado íntimo
            </h3>
            <p className="mt-4 text-[15px] leading-relaxed text-muted-foreground max-w-3xl">
              O ressecamento, as fissuras e a atrofia da mucosa vaginal podem ocorrer no período
              de pré e pós-menopausa, associados à redução dos níveis de estrogênio. Essas
              alterações podem afetar o conforto e a qualidade de vida.
            </p>
            <p className="mt-4 text-[15px] leading-relaxed text-muted-foreground max-w-3xl">
              A avaliação médica permite compreender os sintomas e discutir opções de cuidado,
              seus benefícios, riscos e limitações. O uso do laser de CO₂ na região íntima exige
              indicação individualizada.
            </p>
            <p className="mt-5 text-[11px] uppercase tracking-label text-muted-foreground">
              Queixas e objetivos a discussão na avaliação
            </p>
            <ul className="mt-3 space-y-2 text-[15px] text-muted-foreground">
              <li className="flex items-center gap-3"><span className="h-px w-5 bg-[hsl(30_12%_55%)]" />Incontinência urinária de esforço</li>
              <li className="flex items-center gap-3"><span className="h-px w-5 bg-[hsl(30_12%_55%)]" />Ressecamento, fissuras e atrofia da mucosa vaginal</li>
              <li className="flex items-center gap-3"><span className="h-px w-5 bg-[hsl(30_12%_55%)]" />Alterações de pigmentação e interesse em rejuvenescimento íntimo</li>
            </ul>
            <a
              href={whatsappLink("Olá! Gostaria de saber mais sobre o laser de CO₂ íntimo e agendar uma avaliação com a Dra. Juliana.")}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 inline-flex items-center bg-primary text-primary-foreground px-6 py-3 text-[12px] uppercase tracking-[0.08em] luxury-ease hover:opacity-90 transition-opacity"
            >
              Agendar uma avaliação
            </a>
          </div>

          {/* 3 — Elleva Max */}
          <div className="reveal grid grid-cols-1 lg:grid-cols-12 gap-8 border hairline p-8 md:p-10">
            <div className="lg:col-span-5 flex justify-center items-center bg-secondary/40 p-6">
              <img
                src={images.elleva}
                alt="Ultrassom Microfocado Elleva Max"
                loading="lazy"
                className="w-full max-w-[400px] aspect-[3/4] object-contain"
              />
            </div>
            <div className="lg:col-span-7">
              <h3 className="font-heading font-light text-[24px] md:text-[28px]">
                Ultrassom Microfocado — Elleva Max
              </h3>
              <p className="mt-4 text-[15px] leading-relaxed text-muted-foreground">
                Flacidez facial e corporal, gordura localizada e papada. Estímulo de colágeno e
                definição de contorno, conforme indicação.
              </p>
            </div>
          </div>

          {/* 4 — Fotobiomodulação */}
          <div className="reveal border hairline p-8 md:p-10">
            <h3 className="font-heading font-light text-[24px] md:text-[28px]">
              Laser de fotobiomodulação
            </h3>
            <p className="mt-4 text-[15px] leading-relaxed text-muted-foreground max-w-3xl">
              Apoio à cicatrização e à recuperação dos tecidos, conforme indicação médica.
            </p>
          </div>
        </div>

        <p className="reveal mt-8 italic text-[14px] text-muted-foreground max-w-3xl">
          As aplicações descritas são possibilidades. A indicação é sempre individualizada, após
          avaliação presencial.
        </p>
        <a
          href={whatsappLink("Olá! Gostaria de conhecer os tratamentos disponíveis e agendar uma avaliação com a Dra. Juliana.")}
          target="_blank"
          rel="noopener noreferrer"
          className="reveal mt-8 inline-flex items-center bg-primary text-primary-foreground px-6 py-3.5 text-[13px] uppercase tracking-[0.08em] luxury-ease hover:opacity-90 transition-opacity"
        >
          Conheça os tratamentos
        </a>
      </div>
    </section>
  );
}

export default Technologies;