import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { X, ChevronLeft, ChevronRight, ZoomIn, ZoomOut } from "lucide-react";
import { surgicalMontage } from "@/assets/surgicalMontage";

// A montagem (3030 × 2424) contém 20 fotos em 5 colunas × 4 linhas.
// Cada miniatura recorta uma foto via background-position — mesmas imagens, mesma ordem.
const COLS = 5;
const ROWS = 4;
const TOTAL = COLS * ROWS;

const cellStyle = (index) => {
  const col = index % COLS;
  const row = Math.floor(index / COLS);
  return {
    backgroundImage: `url(${surgicalMontage})`,
    backgroundSize: `${COLS * 100}% ${ROWS * 100}%`,
    backgroundPosition: `${(col * 100) / (COLS - 1)}% ${(row * 100) / (ROWS - 1)}%`,
  };
};

export function SurgicalGallery() {
  const [openIndex, setOpenIndex] = useState(null);
  const [zoom, setZoom] = useState(1);

  const close = () => setOpenIndex(null);
  const prev = () => setOpenIndex((i) => (i - 1 + TOTAL) % TOTAL);
  const next = () => setOpenIndex((i) => (i + 1) % TOTAL);
  const inc = () => setZoom((z) => Math.min(2.5, +(z + 0.25).toFixed(2)));
  const dec = () => setZoom((z) => Math.max(1, +(z - 0.25).toFixed(2)));

  useEffect(() => {
    if (openIndex === null) return;
    document.body.style.overflow = "hidden";
    const onKey = (e) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowLeft") prev();
      if (e.key === "ArrowRight") next();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);