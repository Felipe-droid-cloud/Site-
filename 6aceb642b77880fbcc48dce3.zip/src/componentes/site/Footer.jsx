import { MapPin, Phone, Instagram as InstagramIcon } from "lucide-react";
import { site, whatsappLink } from "@/lib/siteData";

const NAV = [
  { label: "Início", href: "#inicio" },
  { label: "Sobre", href: "#sobre" },
  { label: "Especialidades", href: "#especialidades" },
  { label: "Blefaroplastia", href: "#blefaroplastia" },
  { label: "Tecnologias", href: "#tecnologias" },
  { label: "Resultados", href: "#resultados" },
  { label: "Contato", href: "#contato" },
  { label: "Instagram", href: site.instagram.url },
];

export function Footer() {
  return (
    <footer className="bg-background border-t hairline">
      <div className="mx-auto max-w-[1360px] px-6 md:px-12 py-14">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-5">
            <p className="font-heading font-light text-[26px]">{site.fullName}</p>
            <p className="mt-1 text-[13px] uppercase tracking-label text-muted-foreground">
              {site.specialty}
            </p>
            <p className="mt-4 text-[13px] text-muted-foreground">
              {site.crm} · {site.rqes.join(" · ")}
            </p>
          </div>

          <div className="lg:col-span-3">
            <p className="text-[11px] uppercase tracking-label text-muted-foreground mb-4">Navegação</p>
            <div className="grid grid-cols-2 gap-y-2 gap-x-6">
              {NAV.map((n) => (
                <a
                  key={n.label}
                  href={n.href}
                  target={n.href.startsWith("http") ? "_blank" : undefined}
                  rel={n.href.startsWith("http") ? "noopener noreferrer" : undefined}
                  className="text-[14px] text-muted-foreground hover:text-foreground transition-colors luxury-ease"
                >
                  {n.label}
                </a>
              ))}
            </div>
          </div>

          <div className="lg:col-span-4">
            <p className="text-[11px] uppercase tracking-label text-muted-foreground mb-4">Contato</p>
            <p className="flex items-start gap-3 text-[14px] text-muted-foreground">
              <MapPin className="h-5 w-5 shrink-0 mt-0.5 text-[hsl(30_12%_55%)]" />
              {site.address.full}
            </p>
            <a href={`tel:+${site.phoneIntl}`} className="mt-3 flex items-center gap-3 text-[14px] text-muted-foreground hover:text-foreground transition-colors">
              <Phone className="h-5 w-5 text-[hsl(30_12%_55%)]" />
              {site.phone}
            </a>
            <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="mt-3 flex items-center gap-3 text-[14px] text-muted-foreground hover:text-foreground transition-colors">
              <Phone className="h-5 w-5 text-[hsl(30_12%_55%)]" />
              WhatsApp: {site.whatsapp}
            </a>
            <a href={site.instagram.url} target="_blank" rel="noopener noreferrer" className="mt-3 flex items-center gap-3 text-[14px] text-muted-foreground hover:text-foreground transition-colors">
              <InstagramIcon className="h-5 w-5 text-[hsl(30_12%_55%)]" />
              {site.instagram.handle}
            </a>
          </div>
        </div>

        <div className="mt-12 border-t hairline pt-6">
          <p className="text-[12px] text-muted-foreground leading-relaxed max-w-3xl">
            Este site possui caráter exclusivamente informativo e não substitui uma consulta médica.
          </p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;