const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

export const site = {
  fullName: "Dra. Juliana de Lima Cunha Marques",
  shortName: "Dra. Juliana Cunha",
  specialty: "Dermatologista",
  crm: "CRM-GO 11886",
  rqes: ["RQE 6250", "RQE 6375"],
  affiliations: [
    "Sociedade Brasileira de Dermatologia — SBD",
    "Sociedade Brasileira de Cirurgia Dermatológica — SBCD",
  ],
  clinic: "Clínica Reabilitar",
  address: {
    line: "Rua Catalão, 604 — Setor Central",
    city: "Iporá — GO",
    cep: "CEP 76200-059",
    full: "Rua Catalão, 604 — Setor Central, Iporá — GO, CEP 76200-059",
  },
  phone: "(64) 3674-4255",
  phoneIntl: "556436744255",
  whatsapp: "(64) 98418-6708",
  whatsappIntl: "5564984186708",
  instagram: {
    handle: "@drajulianacunhadermato",
    url: "https://www.instagram.com/drajulianacunhadermato",
  },
  googleReviews:
    "https://www.google.com/search?q=Clínica+Reabilitar+Dra+Juliana+Cunha+Iporá",
  mapsEmbed:
    "https://www.google.com/maps?q=Rua+Catalão,+604,+Iporá,+GO&output=embed",
  mapsDirections:
    "https://www.google.com/maps/dir/?api=1&destination=Rua+Catalão,+604,+Iporá,+GO",
};

// Fotografias reais fornecidas — assets do próprio projeto (servidos pelo build).
export const images = {
  hero: "/images/medica-hero-63.jpg",
  about: "/images/medica-sobre-25.jpg",
  booking: "/images/medica-agendamento-59.jpg",
  blefaro: "/images/medica-blefaroplastia-65.jpg",
  texture: "https://media.db.com/images/public/6abb1aac234e094477848810/99e7345f3_generated_2fb2f2d2.jpg",
  laserCo2: "https://media.db.com/images/public/6abb1aac234e094477848810/b82580416_equip-laser-co2-rennova.jpg",
  elleva: "https://media.db.com/images/public/6abb1aac234e094477848810/eee074842_equip-ultrassom-elleva.jpg",
};

const B = "https://media.db.com/images/public/6abb1aac234e094477848810";
export const beforeAfter = {
  blef1: { before: `${B}/8eb2a1746_blef1-antes.jpg`, after: `${B}/a099e9954_blef1-depois.jpg`, aspect: 1174 / 534, label: "Blefaroplastia — Caso 1" },
  blef2: { before: `${B}/88a1d80f1_blef2-antes.jpg`, after: `${B}/2473d649a_blef2-depois.jpg`, aspect: 590 / 268, label: "Blefaroplastia — Caso 2" },
  perioral: { before: `${B}/7eeca15dd_perioral-antes.jpg`, after: `${B}/23180665e_perioral-depois.jpg`, aspect: 2048 / 1008, label: "Região perioral" },
};

export const NAV_ITEMS = [
  { label: "Início", href: "#inicio" },
  { label: "A Dra. Juliana", href: "#sobre" },
  { label: "Especialidades", href: "#especialidades" },
  { label: "Blefaroplastia", href: "#blefaroplastia" },
  { label: "Tecnologias", href: "#tecnologias" },
  { label: "Resultados", href: "#resultados" },
  { label: "Conteúdos", href: "#conteudos" },
  { label: "Contato", href: "#contato" },
];

export function whatsappLink(text) {
  const msg = text || "Olá, gostaria de agendar uma consulta com a Dra. Juliana Cunha.";
  return `https://wa.me/${site.whatsappIntl}?text=${encodeURIComponent(msg)}`;
}