import { ArrowRight } from "lucide-react";
import { useRevealStagger } from "@/hooks/useReveal";
import { SectionLabel } from "./SectionLabel";
import { whatsappLink } from "@/lib/siteData";

const ITEMS = [
  {
    num: "01",
    title: "Dermatologia Clínica",
    text: "Avaliação, diagnóstico, prevenção e tratamento das doenças da pele, com atenção a queixas como acne, rosácea, manchas, cicatrizes e queda de cabelo.",
  },
  {
    num: "02",
    title: "Cirurgia Dermatológica",
    text: "Avaliação e tratamento cirúrgico de lesões da pele, incluindo cuidados relacionados ao câncer de pele, sinais e outras alterações cutâneas, conforme indicação individual.",
  },
  {
    num: "03",
    title: "Estética Facial e Corporal",
    text: "Cuidados personalizados para o rosto e o corpo, considerando as características, as necessidades e os objetivos de cada paciente.",
  },
];

export function Specialties() {
  const ref = useRevealStagger();
  return (
    <section id="especialidades">
      <div ref={ref} className="mx-auto max-w-[1360px] px-6 md:px-12 py-12 md:py-20">
        <div className="reveal">
          <SectionLabel index="03">Especialidades</SectionLabel>
        </div>
        <h2 className="reveal mt-6 max-w-3xl font-heading font-light text-[30px] md:text-[40px] leading-[1.15] tracking-tight text-balance">
          Uma dermatologia completa, pensada para cada necessidade.
        </h2>

        <div className="mt-12 border-t hairline">
          {ITEMS.map((item) => (
            <div
              key={item.num}
              className="reveal grid grid-cols-1 lg:grid-cols-12 gap-4 lg:gap-8 border-b hairline py-8 lg:py-10"
            >
              <div className="lg:col-span-4 flex items-start gap-4">
                <span className="text-[12px] font-medium text-muted-foreground">{item.num}</span>
                <h3 className="font-heading font-light text-[24px] md:text-[28px] leading-tight">
                  {item.title}
                </h3>
              </div>
              <div className="lg:col-span-7">
                <p className="text-[15px] md:text-[16px] leading-relaxed text-muted-foreground">
                  {item.text}
                </p>
              </div>
              <div className="lg:col-span-1 mt-6 lg:mt-0 flex lg:justify-end items-center">
                <a
                  href={whatsappLink(`Olá! Tenho interesse em ${item.title} e gostaria de agendar uma avaliação com a Dra. Juliana.`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-[13px] uppercase tracking-[0.08em] text-muted-foreground hover:text-foreground transition-colors luxury-ease"
                >
                  Agendar avaliação <ArrowRight className="h-4 w-4" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Specialties;