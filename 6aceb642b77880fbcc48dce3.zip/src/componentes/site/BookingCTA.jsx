import { site, images, whatsappLink } from "@/lib/siteData";

export function BookingCTA() {
  return (
    <section className="relative bg-[#2b2723] text-background overflow-hidden">
      <div className="hidden xl:block absolute top-0 right-0 bottom-0 w-[40%]">
        <img
          src={images.booking}
          alt="Dra. Juliana Cunha"
          loading="lazy"
          className="absolute inset-0 h-full w-full object-contain object-right"
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(to right, #2b2723 0%, rgba(43,39,35,0.92) 30%, rgba(43,39,35,0.35) 60%, rgba(43,39,35,0) 85%), linear-gradient(to top, rgba(43,39,35,0.55) 0%, rgba(43,39,35,0) 14%), linear-gradient(to bottom, rgba(43,39,35,0.55) 0%, rgba(43,39,35,0) 14%)",
          }}
        />
      </div>

      <div className="relative mx-auto max-w-[1400px] px-6 md:px-12 py-16 md:py-24">
        <div className="xl:hidden relative flex justify-center mb-10 -mx-6">
          <img
            src={images.booking}
            alt="Dra. Juliana Cunha"
            loading="lazy"
            className="w-full max-w-[320px] h-auto object-contain"
          />
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background:
                "linear-gradient(to bottom, rgba(43,39,35,0.6) 0%, rgba(43,39,35,0) 15%), linear-gradient(to top, rgba(43,39,35,0.6) 0%, rgba(43,39,35,0) 15%), linear-gradient(to left, rgba(43,39,35,0.7) 0%, rgba(43,39,35,0) 22%), linear-gradient(to right, rgba(43,39,35,0.7) 0%, rgba(43,39,35,0) 22%)",
            }}
          />
        </div>

        <div className="max-w-xl">
          <p className="text-[11px] uppercase tracking-label text-background/60 mb-5">Agendamento</p>
          <h2 className="font-heading font-light text-[30px] md:text-[44px] leading-[1.1] tracking-tight text-balance">
            Sua pele merece uma avaliação individualizada.
          </h2>
          <p className="mt-6 text-[15px] md:text-[16px] leading-relaxed text-background/70">
            Agende sua consulta e converse com a Dra. Juliana sobre suas queixas, objetivos e as
            melhores possibilidades de cuidado para você.
          </p>
          <a
            href={whatsappLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-8 inline-flex items-center bg-background text-foreground px-8 py-4 text-[14px] uppercase tracking-[0.08em] luxury-ease hover:opacity-90 transition-opacity"
          >
            Agendar consulta pelo WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}

export default BookingCTA;