import { useRevealStagger } from "@/hooks/useReveal";
import { SectionLabel } from "./SectionLabel";
import { images, whatsappLink } from "@/lib/siteData";

const CARDS = [
  {
    title: "Blefaroplastia superior",
    text: "Tratamento do excesso de pele da pálpebra superior, que pode comprometer o campo visual.",
  },
  {
    title: "Blefaroplastia inferior",
    text: "Cuidado das bolsas e da flacidez da pálpebra inferior, com abordagem delicada.",
  },
  {
    title: "Associada a outras técnicas",
    text: "Pode ser combinada a procedimentos complementares para um resultado equilibrado.",
  },
];

export function Blepharoplasty() {
  const ref = useRevealStagger();
  return (
    <section id="blefaroplastia" className="bg-[#2b2723] text-background overflow-hidden">
      <div ref={ref} className="mx-auto max-w-[1360px] px-6 md:px-12 py-16 md:py-20">
        <div className="reveal">
          <SectionLabel index="04" className="[&_*]:!text-background/70">
            Blefaroplastia
          </SectionLabel>
        </div>

        <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          {/* Retrato real à esquerda, integrado ao fundo escuro da seção */}
          <div className="reveal lg:col-span-5 order-1 relative">
            <img
              src={images.blefaro}
              alt="Dra. Juliana Cunha"
              loading="lazy"
              className="w-full h-auto object-contain"
            />
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                background:
                  "linear-gradient(to bottom, rgba(43,39,35,0.5) 0%, rgba(43,39,35,0) 14%), linear-gradient(to top, rgba(43,39,35,0.5) 0%, rgba(43,39,35,0) 14%), linear-gradient(to left, rgba(43,39,35,0.65) 0%, rgba(43,39,35,0) 22%)",
              }}
            />
          </div>

          <div className="reveal lg:col-span-7 order-2">
            <h2 className="font-heading font-light text-[30px] md:text-[40px] leading-[1.15] tracking-tight text-balance">
              Blefaroplastia: cuidado com a aparência e a função das pálpebras.
            </h2>
            <p className="mt-5 font-heading font-light text-[20px] md:text-[22px] leading-snug text-background/80">
              Rejuvenescimento da região dos olhos com precisão, equilíbrio e naturalidade.
            </p>
            <p className="mt-6 text-[15px] leading-relaxed text-background/70 max-w-xl">
              A blefaroplastia trata o excesso de pele e as bolsas palpebrais. Quando o excesso
              de pele compromete o campo visual, o procedimento traz também benefício funcional.
              É realizado com anestesia local, conforme avaliação e planejamento médico, com
              segurança e acompanhamento.
            </p>

            <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-px bg-background/15">
              {CARDS.map((c) => (
                <div key={c.title} className="reveal bg-[#2b2723] p-6">
                  <h3 className="font-heading font-light text-[19px]">{c.title}</h3>
                  <p className="mt-2 text-[14px] leading-relaxed text-background/70">{c.text}</p>
                </div>
              ))}
            </div>

            <div className="reveal mt-8 border-t border-background/20 pt-6">
              <p className="text-[11px] uppercase tracking-label text-background/60 mb-2">
                Cirurgia de Castanhares
              </p>
              <p className="text-[15px] leading-relaxed text-background/70 max-w-xl">
                Pode ser associada à blefaroplastia para tratar a região palpebral e elevar os
                supercílios, harmonizando o terço superior do rosto.
              </p>
            </div>

            <a
              href={whatsappLink("Olá! Quero saber mais sobre blefaroplastia e agendar uma avaliação com a Dra. Juliana.")}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-8 inline-flex items-center bg-background text-foreground px-6 py-3.5 text-[13px] uppercase tracking-[0.08em] luxury-ease hover:opacity-90 transition-opacity"
            >
              Quero saber mais sobre blefaroplastia
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Blepharoplasty;