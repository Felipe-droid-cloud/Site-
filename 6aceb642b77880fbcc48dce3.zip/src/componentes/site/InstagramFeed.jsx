import { useEffect, useRef, useState } from "react";
import { Instagram as InstagramIcon } from "lucide-react";
import { useRevealStagger } from "@/hooks/useReveal";
import { SectionLabel } from "./SectionLabel";
import { site } from "@/lib/siteData";

export function InstagramFeed() {
  const ref = useRevealStagger();
  const embedRef = useRef(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const run = () => {
      if (window.instgrm && window.instgrm.Embeds) {
        window.instgrm.Embeds.process();
      }
    };
    if (!document.getElementById("ig-embed-js")) {
      const s = document.createElement("script");
      s.id = "ig-embed-js";
      s.async = true;
      s.src = "https://www.instagram.com/embed.js";
      s.onload = run;
      document.body.appendChild(s);
    } else {
      run();
    }
    const t1 = setTimeout(run, 1500);
    const t2 = setTimeout(run, 4000);
    const t3 = setTimeout(run, 8000);
    // Só recorre ao link direto se o embed realmente não renderizar após 15s
    const check = setTimeout(() => {
      if (!embedRef.current || !embedRef.current.querySelector("iframe")) {
        setFailed(true);
      }
    }, 15000);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(check);
    };
  }, []);

  return (
    <section id="conteudos">
      <div ref={ref} className="mx-auto max-w-[1360px] px-6 md:px-12 py-12 md:py-20">
        <div className="reveal">
          <SectionLabel index="10">Conteúdos</SectionLabel>
        </div>
        <h2 className="reveal mt-6 max-w-3xl font-heading font-light text-[30px] md:text-[40px] leading-[1.15] tracking-tight text-balance">
          Informação e cuidado, também no Instagram.
        </h2>

        <div className="reveal mt-10 flex justify-center">
          {failed ? (
            <div className="w-full max-w-[940px] border hairline bg-card p-10 md:p-14 flex flex-col items-center gap-4 text-center">
              <InstagramIcon className="h-6 w-6 text-muted-foreground" />
              <p className="font-heading font-light text-[24px]">{site.instagram.handle}</p>
              <p className="text-[14px] text-muted-foreground max-w-md">
                Não foi possível carregar o conteúdo do Instagram nesta página. Acesse o perfil
                diretamente:
              </p>
              <a
                href={site.instagram.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center border border-foreground px-6 py-3 text-[13px] uppercase tracking-[0.08em] luxury-ease hover:bg-secondary transition-colors"
              >
                Abrir perfil no Instagram
              </a>
            </div>
          ) : (
            <div ref={embedRef} className="w-full max-w-[760px]">
              <blockquote
                className="instagram-media"
                data-instgrm-permalink={`${site.instagram.url}/`}
                data-instgrm-version="14"
                style={{ background: "#FFF", border: 0, margin: "0 auto", width: "min(760px, 100%)", minWidth: "326px", padding: 0 }}
              />
            </div>
          )}
        </div>

        <div className="reveal mt-6 max-w-[940px] mx-auto flex justify-end">
            <a
              href={site.instagram.url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-[13px] uppercase tracking-[0.08em] border-b border-foreground pb-1 luxury-ease hover:opacity-70 transition-opacity"
            >
              <InstagramIcon className="h-4 w-4" />
              Ver perfil no Instagram →
            </a>
          </div>
      </div>
    </section>
  );
}

export default InstagramFeed;