import { useRevealStagger } from "@/hooks/useReveal";
import { SectionLabel } from "./SectionLabel";

const PILLARS = [
  {
    title: "Dermatologia",
    text: "Diagnóstico, prevenção e tratamento das doenças da pele.",
  },
  {
    title: "Cirurgia Dermatológica",
    text: "Procedimentos cirúrgicos dermatológicos realizados com planejamento e segurança.",
  },
  {
    title: "Rejuvenescimento",
    text: "Tratamentos personalizados para preservar a naturalidade e melhorar a qualidade da pele.",
  },
];

export function Authority() {
  const ref = useRevealStagger();
  return (
    <section className="border-t hairline">
      <div ref={ref} className="mx-auto max-w-[1360px] px-6 md:px-12 py-12 md:py-20">
        <div className="reveal">
          <SectionLabel index="01">Autoridade</SectionLabel>
        </div>
        <h2 className="reveal mt-6 max-w-3xl font-heading font-light text-[30px] md:text-[40px] leading-[1.15] tracking-tight text-balance">
          Conhecimento médico aliado à experiência e à precisão.
        </h2>
        <p className="reveal mt-6 max-w-2xl text-[15px] md:text-[16px] leading-relaxed text-muted-foreground">
          A dermatologia exige atualização constante, olhar clínico e compreensão individual de
          cada paciente. Dra. Juliana Cunha atua na dermatologia clínica e cirurgia, unindo
          conhecimento médico, técnicas modernas e uma abordagem cuidadosa em cada tratamento.
        </p>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-px bg-[hsl(30_12%_80%_/_0.6)]">
          {PILLARS.map((p) => (
            <div key={p.title} className="reveal bg-background p-8 md:p-10">
              <h3 className="font-heading font-light text-[22px] md:text-[24px]">{p.title}</h3>
              <p className="mt-4 text-[15px] leading-relaxed text-muted-foreground">{p.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Authority;