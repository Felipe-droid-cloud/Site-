import { useState } from "react";
import { Plus, Minus } from "lucide-react";
import { useRevealStagger } from "@/hooks/useReveal";
import { SectionLabel } from "./SectionLabel";

const ITEMS = [
  {
    q: "Quando devo procurar um dermatologista?",
    a: "Sempre que houver alterações na pele, cabelos ou unhas — manchas, lesões, queda de cabelo, acne, cicatriz persistente — ou para prevenção e acompanhamento da saúde da pele. A avaliação precoce auxilia no diagnóstico e no tratamento adequado.",
  },
  {
    q: "Como funciona a primeira consulta?",
    a: "Inclui anamnese, exame clínico da pele e conversa sobre queixas e objetivos. A partir daí é definido um plano individualizado.",
  },
  {
    q: "Como saber se a blefaroplastia é indicada para mim?",
    a: "Quando há excesso de pele ou bolsas palpebrais — especialmente se comprometem o campo visual. A indicação depende de avaliação presencial.",
  },
  {
    q: "A blefaroplastia pode ser associada à cirurgia de Castanhares?",
    a: "Sim. A associação pode tratar a região palpebral e elevar os supercílios, harmonizando o terço superior do rosto.",
  },
  {
    q: "Como funciona a recuperação da blefaroplastia?",
    a: "Realizada com anestesia local, tem recuperação progressiva, com edema e equimoses transitórios. O acompanhamento médico orienta cada etapa.",
  },
  {
    q: "O Laser de CO₂ é indicado para quais tratamentos?",
    a: "Atua na qualidade, textura e firmeza da pele, em manchas, rugas e cicatrizes, promovendo rejuvenescimento facial e melhora da flacidez palpebral.",
  },
  {
    q: "O ultrassom microfocado pode tratar papada e flacidez?",
    a: "Tecnologia que estimula colágeno e trata flacidez facial e corporal, gordura localizada e papada, conforme indicação.",
  },
  {
    q: "Os tratamentos estéticos atendem também o corpo?",
    a: "Sim. Há protocolos para flacidez, contorno e qualidade da pele corporal, sempre personalizados após avaliação.",
  },
  {
    q: "Os tratamentos são personalizados?",
    a: "Sim. Não há fórmula pronta. Cada protocolo é definido a partir da avaliação clínica, do tipo de pele e dos objetivos individuais.",
  },
];

function Item({ item, defaultOpen }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b hairline">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between gap-4 py-5 text-left"
        aria-expanded={open}
      >
        <span className="font-heading font-light text-[18px] md:text-[20px]">{item.q}</span>
        {open ? <Minus className="h-5 w-5 shrink-0 text-muted-foreground" /> : <Plus className="h-5 w-5 shrink-0 text-muted-foreground" />}
      </button>
      <div
        className="overflow-hidden transition-all duration-500 luxury-ease"
        style={{ maxHeight: open ? "400px" : "0px", opacity: open ? 1 : 0 }}
      >
        <p className="pb-6 pr-8 text-[15px] leading-relaxed text-muted-foreground">{item.a}</p>
      </div>
    </div>
  );
}

export function FAQ() {
  const ref = useRevealStagger();
  return (
    <section className="bg-secondary/40">
      <div ref={ref} className="mx-auto max-w-[1360px] px-6 md:px-12 py-12 md:py-20">
        <div className="reveal">
          <SectionLabel index="11">Perguntas frequentes</SectionLabel>
        </div>
        <h2 className="reveal mt-6 max-w-3xl font-heading font-light text-[30px] md:text-[40px] leading-[1.15] tracking-tight text-balance">
          Dúvidas comuns.
        </h2>
        <div className="reveal mt-10 max-w-3xl border-t hairline">
          {ITEMS.map((item, i) => (
            <Item key={item.q} item={item} defaultOpen={i === 0} />
          ))}
        </div>
      </div>
    </section>
  );
}

export default FAQ;