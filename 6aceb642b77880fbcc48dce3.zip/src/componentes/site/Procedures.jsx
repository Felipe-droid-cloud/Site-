import { ArrowRight } from "lucide-react";
import { useRevealStagger } from "@/hooks/useReveal";
import { SectionLabel } from "./SectionLabel";
import { whatsappLink } from "@/lib/siteData";

const ITEMS = [
  { name: "Blefaroplastia", desc: "Rejuvenescimento da região dos olhos." },
  { name: "Cirurgia de Castanhares", desc: "Tratamento da região palpebral e supercílios." },
  { name: "Toxina botulínica", desc: "Suavização de rugas de expressão." },
  { name: "Laser de CO₂", desc: "Renovação e qualidade da pele." },
  { name: "Ultrassom microfocado", desc: "Estímulo de colágeno e firmeza." },
  { name: "Tratamentos de rejuvenescimento", desc: "Protocolos personalizados." },
  { name: "Tratamentos para flacidez", desc: "Firmeza e contorno." },
  { name: "Tratamentos para manchas", desc: "Uniformidade do tom da pele." },
  { name: "Protocolos personalizados", desc: "Estratégias individuais." },
];

export function Procedures() {
  const ref = useRevealStagger();
  return (
    <section className="bg-secondary/40">
      <div ref={ref} className="mx-auto max-w-[1360px] px-6 md:px-12 py-12 md:py-20">
        <div className="reveal">
          <SectionLabel index="06">Procedimentos</SectionLabel>
        </div>
        <h2 className="reveal mt-6 max-w-3xl font-heading font-light text-[30px] md:text-[40px] leading-[1.15] tracking-tight text-balance">
          Tratamentos conduzidos com critério médico.
        </h2>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-px bg-[hsl(30_12%_80%_/_0.6)]">
          {ITEMS.map((item) => (
            <a
              key={item.name}
              href={whatsappLink(`Olá! Gostaria de saber mais sobre ${item.name} e agendar uma avaliação com a Dra. Juliana.`)}
              target="_blank"
              rel="noopener noreferrer"
              className="reveal group block bg-background p-8 luxury-ease hover:bg-secondary/60 transition-colors"
            >
              <h3 className="font-heading font-light text-[20px]">{item.name}</h3>
              <p className="mt-3 text-[14px] leading-relaxed text-muted-foreground">{item.desc}</p>
              <span className="mt-5 inline-flex items-center gap-2 text-[12px] uppercase tracking-[0.08em] text-foreground">
                Saiba mais
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1 luxury-ease" />
              </span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Procedures;