import { useRevealStagger } from "@/hooks/useReveal";
import { SectionLabel } from "./SectionLabel";
import { site, images } from "@/lib/siteData";

const FORMATION = [
  {
    title: "Graduação em Medicina",
    inst: "UFJF — Universidade Federal de Juiz de Fora.",
  },
  {
    title: "Residência em Clínica Médica",
    inst: "FHEMIG — Fundação Hospitalar do Estado de Minas Gerais.",
  },
  {
    title: "Pós Graduação em Dermatologia",
    inst: "UNIRIO — Universidade Federal do Estado do Rio de Janeiro.",
  },
  {
    title: "Pós-graduação em Estética Médica",
    inst: "Fundação Técnico Educacional Souza Marques.",
  },
];

export function About() {
  const ref = useRevealStagger();
  return (
    <section id="sobre" className="bg-[#7a6e60] text-[#faf6f0]">
      <div ref={ref} className="mx-auto max-w-[1200px] px-6 md:px-12 py-14 md:py-20">
        <div className="reveal">
          <SectionLabel index="02" className="[&_*]:!text-[#faf6f0]/70">
            A Dra. Juliana
          </SectionLabel>
        </div>

        {/* Apresentação + retrato + formação em composição coesa */}
        <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
          <div className="reveal lg:col-span-5 order-2 lg:order-1 flex justify-center lg:justify-start">
            <img
              src={images.about}
              alt={site.fullName}
              loading="lazy"
              className="w-full max-w-[440px] h-auto object-contain"
            />
          </div>

          <div className="reveal lg:col-span-7 order-1 lg:order-2">
            <h2 className="font-heading font-light text-[30px] md:text-[38px] leading-[1.15] tracking-tight text-balance">
              {site.fullName}
            </h2>
            <blockquote className="mt-5 border-l-2 border-[#faf6f0]/40 pl-5 font-heading italic font-light text-[19px] md:text-[21px] leading-snug text-[#faf6f0]/95">
              “Tenho um caso de amor com a Dermatologia porque esta especialidade tem o propósito de cuidar, nada menos, do que o nosso maior órgão: a pele.”
            </blockquote>
            <p className="mt-5 text-[15px] md:text-[16px] leading-relaxed text-[#faf6f0]/80">
              <span className="text-[#faf6f0] font-medium">20 anos dedicados à pele.</span>{" "}
              A Dra. Juliana atua em dermatologia clínica e cirúrgica, rejuvenescimento facial e
              corporal e tecnologias dermatológicas, com abordagem individualizada e foco em
              naturalidade.
            </p>

            {/* Formação — junto do texto, sem vazio */}
            <div className="mt-9">
              <p className="text-[11px] uppercase tracking-label text-[#faf6f0]/60 mb-5">Formação</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-10 gap-y-5">
                {FORMATION.map((f) => (
                  <div key={f.title} className="border-t border-[#faf6f0]/25 pt-4">
                    <p className="text-[17px] md:text-[18px]">{f.title}</p>
                    <p className="mt-1 text-[15px] leading-relaxed text-[#faf6f0]/70">{f.inst}</p>
                  </div>
                ))}
              </div>
              <div className="border-t border-[#faf6f0]/25 pt-4 mt-5">
                <p className="text-[17px] md:text-[18px]">Atualização contínua</p>
                <p className="mt-1 text-[15px] text-[#faf6f0]/70">
                  Participação em cursos e congressos nacionais e internacionais ao longo dos anos.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Bloco compacto final */}
        <div className="reveal mt-10 border-t border-[#faf6f0]/25 pt-6 flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-10">
          <p className="text-[14px] text-[#faf6f0]/85 whitespace-nowrap">
            {site.crm} · {site.rqes.join(" · ")}
          </p>
          <p className="text-[14px] text-[#faf6f0]/70">
            Membro titular da Sociedade Brasileira de Dermatologia e da Sociedade Brasileira de
            Cirurgia Dermatológica.
          </p>
        </div>

        <div className="reveal mt-8">
          <a
            href="#especialidades"
            className="inline-flex items-center gap-2 text-[13px] uppercase tracking-[0.08em] text-[#faf6f0] border-b border-[#faf6f0] pb-1 luxury-ease hover:opacity-70 transition-opacity"
          >
            Conheça minha trajetória
          </a>
        </div>
      </div>
    </section>
  );
}

export default About;