import { ArrowRight } from "lucide-react";
import { site, images, whatsappLink } from "@/lib/siteData";

const HERO_COPY = {
  label: "Dermatologia · Cirurgia Dermatológica · Blefaroplastia",
  subtitle: "Dermatologia, cirurgia e rejuvenescimento com precisão e naturalidade.",
  body: "Uma abordagem médica individualizada para cuidar da saúde da pele, preservar sua identidade e alcançar resultados naturais.",
};

function Credentials() {
  return (
    <div className="mt-10 flex items-center gap-4">
      <span className="h-px w-10 bg-[hsl(30_12%_55%)]" />
      <p className="text-[11px] uppercase tracking-label text-background/60">
        {site.crm} · {site.rqes.join(" · ")}
      </p>
    </div>
  );
}

function Ctas({ stacked }) {
  return (
    <div className={`mt-8 flex gap-3 ${stacked ? "flex-col" : "flex-col sm:flex-row"}`}>
      <a
        href={whatsappLink()}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center justify-center bg-background text-foreground px-6 py-3.5 text-[13px] uppercase tracking-[0.08em] luxury-ease hover:opacity-90 transition-opacity"
      >
        Agendar consulta
      </a>
      <a
        href="#sobre"
        className="inline-flex items-center justify-center border border-background/40 text-background px-6 py-3.5 text-[13px] uppercase tracking-[0.08em] luxury-ease hover:bg-background/10 transition-colors"
      >
        Conheça a Dra. Juliana <ArrowRight className="ml-2 h-4 w-4 sm:hidden" />
      </a>
    </div>
  );
}

export function Hero() {
  return (
    <section id="inicio" className="relative bg-[#2b2723] text-background overflow-hidden">
      {/* Desktop: texto à esquerda, retrato integrado ao fundo à direita, dentro do contêiner */}
      <div className="mx-auto max-w-[1400px] px-6 md:px-12">
        <div className="lg:grid lg:grid-cols-12 lg:min-h-[790px] xl:min-h-[850px]">
          <div className="lg:col-span-6 flex flex-col justify-center pt-32 pb-16 lg:py-24 max-w-xl">
            <p className="text-[12px] uppercase tracking-label text-background/70">
              {HERO_COPY.label}
            </p>
            <h1 className="mt-6 font-heading font-light text-[38px] md:text-[48px] xl:text-[54px] leading-[1.05] tracking-tight text-balance">
              {site.shortName}
            </h1>
            <p className="mt-6 font-heading font-light text-[22px] md:text-[24px] leading-snug text-background/90">
              {HERO_COPY.subtitle}
            </p>
            <p className="mt-5 text-[15px] md:text-[16px] leading-relaxed text-background/70">
              {HERO_COPY.body}
            </p>
            <Ctas />
            <Credentials />
          </div>

          <div className="hidden lg:block lg:col-span-6 relative">
            <img
              src={images.hero}
              alt="Dra. Juliana Cunha"
              loading="eager"
              className="absolute bottom-0 right-[2%] h-[92%] w-auto object-contain object-bottom"
            />
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                background:
                  "linear-gradient(to right, #2b2723 0%, rgba(43,39,35,0.6) 22%, rgba(43,39,35,0) 55%), linear-gradient(to top, rgba(43,39,35,0.45) 0%, rgba(43,39,35,0) 16%), linear-gradient(to bottom, rgba(43,39,35,0.5) 0%, rgba(43,39,35,0) 14%)",
              }}
            />
          </div>
        </div>
      </div>

      {/* Mobile: texto seguido de fotografia, sobre o mesmo fundo contínuo */}
      <div className="lg:hidden flex flex-col items-center px-6 pt-32 pb-16">
        <div className="w-full max-w-xl text-center">
          <p className="text-[12px] uppercase tracking-label text-background/70">
            {HERO_COPY.label}
          </p>
          <h1 className="mt-5 font-heading font-light text-[38px] leading-[1.05] tracking-tight">
            {site.shortName}
          </h1>
          <p className="mt-4 font-heading font-light text-[21px] leading-snug text-background/90">
            {HERO_COPY.subtitle}
          </p>
          <p className="mt-4 text-[15px] leading-relaxed text-background/70">
            {HERO_COPY.body}
          </p>
          <Ctas stacked />
          <div className="mt-8 flex items-center justify-center gap-4">
            <span className="h-px w-10 bg-[hsl(30_12%_55%)]" />
            <p className="text-[11px] uppercase tracking-label text-background/60">
              {site.crm} · {site.rqes.join(" · ")}
            </p>
          </div>
        </div>

        <div className="relative mt-10 flex justify-center">
          <img
            src={images.hero}
            alt="Dra. Juliana Cunha"
            loading="eager"
            className="w-full max-w-[330px] h-auto object-contain"
          />
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background:
                "linear-gradient(to bottom, rgba(43,39,35,0.55) 0%, rgba(43,39,35,0) 12%), linear-gradient(to top, rgba(43,39,35,0.55) 0%, rgba(43,39,35,0) 12%), linear-gradient(to left, rgba(43,39,35,0.6) 0%, rgba(43,39,35,0) 20%), linear-gradient(to right, rgba(43,39,35,0.6) 0%, rgba(43,39,35,0) 20%)",
            }}
          />
        </div>
      </div>
    </section>
  );
}

export default Hero;