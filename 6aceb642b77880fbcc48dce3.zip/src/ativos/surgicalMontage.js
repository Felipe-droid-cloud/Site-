// Montagem de cirurgia dermatológica — 20 fotos (5 colunas × 4 linhas), recortes aprovados.
// Asset real do projeto, servido pelo build a partir de /public/images.
export const surgicalMontage = "/images/cirurgia-montagem-recortada.png";