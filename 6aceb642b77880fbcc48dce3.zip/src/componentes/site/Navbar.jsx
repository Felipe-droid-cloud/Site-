import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { NAV_ITEMS, site, whatsappLink } from "@/lib/siteData";

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 h-20 bg-background/95 backdrop-blur-xl border-b hairline transition-shadow ${
          scrolled ? "shadow-sm" : ""
        }`}
      >
        <div className="mx-auto flex h-full max-w-[1360px] items-center justify-between px-6 md:px-12">
          <a href="#inicio" className="flex flex-col leading-none" onClick={() => setOpen(false)}>
            <span className="font-heading text-[26px] font-light text-foreground">
              {site.shortName}
            </span>
            <span className="text-[10px] uppercase tracking-label text-muted-foreground mt-1">
              Dermatologia · Cirurgia
            </span>
          </a>

          <nav className="hidden xl:flex flex-1 items-center justify-center gap-4 2xl:gap-7 2xl:px-10 min-w-0">
            {NAV_ITEMS.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="whitespace-nowrap text-[11px] 2xl:text-[12px] uppercase tracking-[0.06em] 2xl:tracking-[0.08em] text-muted-foreground hover:text-foreground transition-colors luxury-ease"
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <a
              href={whatsappLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden lg:inline-flex items-center justify-center whitespace-nowrap bg-primary px-7 py-3 text-[13px] uppercase tracking-[0.08em] text-primary-foreground luxury-ease hover:opacity-90 transition-opacity"
            >
              Agendar consulta
            </a>
            <button
              className="xl:hidden p-2 -mr-2 text-foreground"
              aria-label="Abrir menu"
              onClick={() => setOpen(true)}
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </header>

      {open && (
        <div className="fixed inset-0 z-[70] bg-background xl:hidden flex flex-col">
          <div className="flex h-20 items-center justify-between px-6 border-b hairline">
            <span className="font-heading text-[24px] font-light">{site.shortName}</span>
            <button autoFocus className="p-2 -mr-2" aria-label="Fechar menu" onClick={() => setOpen(false)}>
              <X className="h-6 w-6" />
            </button>
          </div>
          <nav className="flex flex-1 flex-col justify-center px-6 gap-1">
            {NAV_ITEMS.map((item, i) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="reveal is-visible font-heading text-[28px] font-light py-2 border-b hairline"
                style={{ transitionDelay: `${i * 60}ms` }}
              >
                {item.label}
              </a>
            ))}
          </nav>
          <div className="px-6 py-8 border-t hairline">
            <a
              href={whatsappLink()}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setOpen(false)}
              className="block w-full bg-primary text-center py-4 text-[13px] uppercase tracking-[0.08em] text-primary-foreground"
            >
              Agendar consulta
            </a>
            <p className="mt-4 text-[11px] uppercase tracking-label text-muted-foreground text-center">
              {site.crm} · {site.rqes.join(" · ")}
            </p>
          </div>
        </div>
      )}
    </>
  );
}

export default Navbar;