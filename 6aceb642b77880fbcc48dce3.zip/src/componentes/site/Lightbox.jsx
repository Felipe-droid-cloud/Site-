import { useEffect } from "react";
import { X } from "lucide-react";

export function Lightbox({ open, onClose, children, footer }) {
  useEffect(() => {
    if (!open) return;
    document.body.style.overflow = "hidden";
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[90] bg-black/85 backdrop-blur flex items-center justify-center p-4 md:p-8"
      onClick={onClose}
    >
      <button
        onClick={onClose}
        aria-label="Fechar"
        className="absolute top-5 right-5 text-white/80 hover:text-white p-2"
      >
        <X className="h-7 w-7" />
      </button>
      <div
        className="relative max-w-4xl w-full max-h-[88vh] flex flex-col items-center"
        onClick={(e) => e.stopPropagation()}
      >
        {children}
        {footer && (
          <p className="mt-4 text-center text-[12px] text-white/60 max-w-2xl leading-relaxed">
            {footer}
          </p>
        )}
      </div>
    </div>
  );
}

export default Lightbox;