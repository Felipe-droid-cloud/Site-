export function SectionLabel({ index, children, className = "" }) {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <span className="h-px w-6 bg-[hsl(30_12%_55%)]" />
      <span className="text-[11px] uppercase tracking-label text-muted-foreground">
        {children}
      </span>
    </div>
  );
}

export default SectionLabel;