import { useCallback, useEffect, useRef, useState } from "react";
import { Maximize2 } from "lucide-react";

export function BeforeAfterSlider({ before, after, aspect = 2, label = "", onExpand }) {
  const [pos, setPos] = useState(50);
  const containerRef = useRef(null);
  const dragging = useRef(false);

  const updateFromClientX = useCallback((clientX) => {
    const el = containerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = Math.min(Math.max(clientX - rect.left, 0), rect.width);
    setPos((x / rect.width) * 100);
  }, []);

  useEffect(() => {
    const onMove = (e) => {
      if (!dragging.current) return;
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      updateFromClientX(clientX);
    };
    const onUp = () => (dragging.current = false);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    window.addEventListener("touchmove", onMove, { passive: true });
    window.addEventListener("touchend", onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
      window.removeEventListener("touchmove", onMove);
      window.removeEventListener("touchend", onUp);
    };
  }, [updateFromClientX]);

  const onKeyDown = (e) => {
    if (e.key === "ArrowLeft") setPos((p) => Math.max(0, p - (e.shiftKey ? 10 : 2)));
    else if (e.key === "ArrowRight") setPos((p) => Math.min(100, p + (e.shiftKey ? 10 : 2)));
    else if (e.key === "Home") setPos(0);
    else if (e.key === "End") setPos(100);
  };

  return (
    <figure className="relative">
      <div
        ref={containerRef}
        className="relative w-full overflow-hidden select-none bg-black"
        style={{ aspectRatio: String(aspect) }}
        onMouseDown={(e) => {
          dragging.current = true;
          updateFromClientX(e.clientX);
        }}
        onTouchStart={(e) => {
          dragging.current = true;
          updateFromClientX(e.touches[0].clientX);
        }}
      >
        <img src={after} alt="Depois" loading="lazy" className="absolute inset-0 h-full w-full object-cover" draggable={false} />
        <img
          src={before}
          alt="Antes"
          loading="lazy"
          className="absolute inset-0 h-full w-full object-cover"
          style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}
          draggable={false}
        />

        <span className="absolute top-3 left-3 bg-black/60 text-white text-[11px] uppercase tracking-label px-2 py-1">
          Antes
        </span>
        <span className="absolute top-3 right-3 bg-black/60 text-white text-[11px] uppercase tracking-label px-2 py-1">
          Depois
        </span>

        <div
          className="absolute top-0 bottom-0 w-0.5 bg-white pointer-events-none"
          style={{ left: `${pos}%` }}
        />
        <button
          type="button"
          role="slider"
          aria-label="Comparar antes e depois"
          aria-valuenow={Math.round(pos)}
          aria-valuemin={0}
          aria-valuemax={100}
          onKeyDown={onKeyDown}
          className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 h-10 w-10 rounded-full bg-white shadow-lg flex items-center justify-center cursor-ew-resize"
          style={{ left: `${pos}%` }}
        >
          <span className="flex">
            <svg width="10" height="14" viewBox="0 0 10 14" fill="none"><path d="M7 1L1 7l6 6" stroke="#2b2723" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
            <svg width="10" height="14" viewBox="0 0 10 14" fill="none"><path d="M3 1l6 6-6 6" stroke="#2b2723" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </span>
        </button>
      </div>
      <figcaption className="mt-3 flex items-center justify-between">
        <span className="text-[12px] uppercase tracking-label text-muted-foreground">{label}</span>
        {onExpand && (
          <button
            onClick={onExpand}
            className="inline-flex items-center gap-1.5 text-[12px] uppercase tracking-label text-muted-foreground hover:text-foreground transition-colors"
          >
            <Maximize2 className="h-3.5 w-3.5" /> Ampliar imagem
          </button>
        )}
      </figcaption>
    </figure>
  );
}

export default BeforeAfterSlider;